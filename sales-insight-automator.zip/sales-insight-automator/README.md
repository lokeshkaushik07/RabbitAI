# 🐇 Sales Insight Automator — Rabbitt AI

> Upload a sales CSV or Excel file → AI generates an executive brief → Delivers it to your inbox.

[![CI](https://github.com/your-org/sales-insight-automator/actions/workflows/ci.yml/badge.svg)](https://github.com/your-org/sales-insight-automator/actions)
[![License: Proprietary](https://img.shields.io/badge/License-Proprietary-red.svg)]()

---

## 📋 Table of Contents

1. [Architecture Overview](#architecture-overview)  
2. [Quick Start — docker compose](#quick-start--docker-compose)  
3. [Environment Variables](#environment-variables)  
4. [Security Design](#security-design)  
5. [API Documentation](#api-documentation)  
6. [CI/CD Pipeline](#cicd-pipeline)  
7. [Deployment Guide](#deployment-guide)  
8. [Project Structure](#project-structure)  

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│  Browser / Client                                        │
│  Next.js 14 SPA (Vercel)                                 │
│  • Drag-and-drop file upload                            │
│  • Real-time loading / success / error states           │
└─────────────────┬───────────────────────────────────────┘
                  │  POST /api/v1/upload  (multipart/form-data)
                  │  Header: X-API-Key
                  ▼
┌─────────────────────────────────────────────────────────┐
│  FastAPI Backend (Render / Docker)                      │
│                                                         │
│  ┌──────────────┐  ┌─────────────┐  ┌───────────────┐  │
│  │ Data Parser  │→ │  AI Engine  │→ │ Email Service │  │
│  │ pandas       │  │ Gemini/Groq │  │ SendGrid      │  │
│  └──────────────┘  └─────────────┘  └───────────────┘  │
│                                                         │
│  Security Stack:                                        │
│  • X-API-Key auth  • Rate limiting (slowapi)            │
│  • CORS whitelist  • Security headers                   │
│  • Input validation • Non-root Docker user              │
└─────────────────────────────────────────────────────────┘
```

**Stack:**
| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, TypeScript, CSS Modules |
| Backend | FastAPI, Python 3.12, Uvicorn |
| AI | Google Gemini 1.5 Flash (or Groq Llama 3) |
| Email | SendGrid |
| Containerisation | Docker (multi-stage), Docker Compose |
| CI/CD | GitHub Actions |
| Hosting | Vercel (frontend) + Render (backend) |

---

## Quick Start — docker compose

### Prerequisites
- Docker ≥ 24 and Docker Compose v2
- API keys: Gemini _or_ Groq, SendGrid

### 1. Clone and configure

```bash
git clone https://github.com/your-org/sales-insight-automator.git
cd sales-insight-automator

# Copy and populate both env files
cp .env.example .env
cp backend/.env.example backend/.env
```

Edit `backend/.env` with your real API keys (see [Environment Variables](#environment-variables)).

### 2. Spin up the stack

```bash
docker compose up --build
```

| Service | URL |
|---------|-----|
| Frontend | http://localhost:3000 |
| Backend API | http://localhost:8000 |
| Swagger UI | http://localhost:8000/docs |
| ReDoc | http://localhost:8000/redoc |
| Health check | http://localhost:8000/health |

### 3. Test the upload endpoint

```bash
curl -X POST http://localhost:8000/api/v1/upload \
  -H "X-API-Key: your-api-key-here" \
  -F "file=@sales_q1_2026.csv" \
  -F "recipient_email=you@example.com"
```

### 4. Tear down

```bash
docker compose down
```

---

## Environment Variables

All required keys. Copy `backend/.env.example` → `backend/.env`.

| Variable | Required | Description |
|---|---|---|
| `API_KEY` | ✅ | Shared secret for `X-API-Key` header auth |
| `ALLOWED_ORIGINS` | ✅ | Comma-separated CORS-allowed origins |
| `AI_PROVIDER` | ✅ | `gemini` or `groq` |
| `GEMINI_API_KEY` | ⚠️ | Required if `AI_PROVIDER=gemini` |
| `GROQ_API_KEY` | ⚠️ | Required if `AI_PROVIDER=groq` |
| `SENDGRID_API_KEY` | ✅ | SendGrid API key (`SG.*`) |
| `SENDGRID_FROM_EMAIL` | ✅ | Verified sender address |
| `MAX_FILE_SIZE_MB` | ✅ | Default `10` |
| `RATE_LIMIT_UPLOAD` | ✅ | Default `10/minute` |
| `ENVIRONMENT` | ✅ | `production` or `development` |

---

## Security Design

### 1 — API Key Authentication
Every `/api/v1/*` endpoint requires an `X-API-Key` header.  
The key is validated server-side against `settings.API_KEY` (injected at runtime via env vars).  
401/403 responses reveal no server internals.

```
X-API-Key: <32-byte hex secret>
```

Generate a strong key:
```bash
openssl rand -hex 32
```

### 2 — Rate Limiting
`slowapi` enforces per-IP limits:

| Endpoint | Limit |
|---|---|
| `POST /api/v1/upload` | 10 req / min |
| All other routes | 60 req / min |

Exceeding the limit returns `HTTP 429` with a `Retry-After` header.

### 3 — CORS Whitelist
Only origins listed in `ALLOWED_ORIGINS` are permitted.  
Methods restricted to `GET` and `POST` only.

### 4 — Strict Input Validation
- **File extension** allow-list: `.csv`, `.xlsx`, `.xls` only  
- **File size** hard cap (default 10 MB) enforced before any parsing  
- **Email** validated against RFC-5321 regex + Pydantic `EmailStr`  
- **Filename** sanitised with `os.path.basename` to prevent path traversal  
- **Row limit**: max 50,000 rows to prevent resource exhaustion

### 5 — Security Headers (every response)
```
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
Referrer-Policy: strict-origin-when-cross-origin
Strict-Transport-Security: max-age=63072000; includeSubDomains
```
Server version header is stripped.

### 6 — Least-Privilege Container
The Docker runtime stage runs as a **non-root user** (`appuser`).  
The filesystem is mounted **read-only** in `docker-compose.yml`,  
with `/tmp` as the only writable tmpfs.

### 7 — Dependency & Static Analysis
The CI pipeline runs:
- **Bandit** (Python SAST) on every PR
- **Ruff** linting + **mypy** type-checking
- **ESLint** + TypeScript strict mode on the frontend

---

## API Documentation

Live Swagger UI is available at `GET /docs`.  
OpenAPI JSON schema at `GET /openapi.json`.

### Endpoints

#### `GET /health`
No auth required. Returns liveness status.

```json
{ "status": "healthy", "version": "1.0.0", "environment": "production" }
```

#### `POST /api/v1/upload`
**Headers:** `X-API-Key: <secret>`  
**Body:** `multipart/form-data`

| Field | Type | Description |
|---|---|---|
| `file` | File | `.csv` or `.xlsx`, max 10 MB |
| `recipient_email` | string | Valid email address |

**200 Response:**
```json
{
  "success": true,
  "message": "Sales brief generated and dispatched successfully.",
  "recipient": "ceo@company.com",
  "filename": "sales_q1_2026.csv",
  "rows_processed": 6,
  "summary_preview": "Q1 2026 sales performance was dominated by Electronics..."
}
```

**Error codes:** `400` (bad input), `403` (auth), `413` (file too large), `429` (rate limit), `502` (upstream AI/email error).

---

## CI/CD Pipeline

Triggered on every **Pull Request** to `main` and on **push** to `main`.

```
PR opened / updated
       │
       ├─► Backend checks (parallel)
       │     • pip install → ruff lint → mypy type-check → bandit SAST
       │
       ├─► Frontend checks (parallel)
       │     • npm ci → eslint → tsc --noEmit
       │
       └─► Docker build validation (after both checks pass)
             • Build backend image (layer-cached via GitHub Actions cache)
             • Build frontend image
```

All jobs must pass before a PR can be merged (enforce via branch protection rules).

---

## Deployment Guide

### Backend → Render

1. Create a new **Web Service** pointing to your repo, root dir `backend/`.
2. Set **Build Command:** `pip install -r requirements.txt`
3. Set **Start Command:** `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
4. Add all environment variables from `backend/.env.example` in the Render dashboard.
5. Set `ALLOWED_ORIGINS` to your Vercel frontend URL.

### Frontend → Vercel

1. Import repo in Vercel, set **Root Directory** to `frontend/`.
2. Add env vars:
   - `NEXT_PUBLIC_API_URL` → your Render backend URL
   - `NEXT_PUBLIC_API_KEY` → your `API_KEY` value
3. Deploy. Vercel auto-builds on every push to `main`.

---

## Project Structure

```
sales-insight-automator/
├── backend/
│   ├── app/
│   │   ├── core/
│   │   │   ├── config.py        # Pydantic Settings (env-driven)
│   │   │   └── security.py      # API key dependency + allow-lists
│   │   ├── models/
│   │   │   └── schemas.py       # Request / response Pydantic models
│   │   ├── routers/
│   │   │   ├── health.py        # GET /health
│   │   │   └── upload.py        # POST /api/v1/upload
│   │   ├── services/
│   │   │   ├── ai_service.py    # Gemini / Groq integration
│   │   │   ├── data_parser.py   # CSV / XLSX → statistics dict
│   │   │   └── email_service.py # SendGrid delivery + HTML template
│   │   └── main.py              # FastAPI app, middleware, router wiring
│   ├── requirements.txt
│   ├── Dockerfile               # Multi-stage, non-root runtime
│   └── .env.example
│
├── frontend/
│   ├── src/
│   │   ├── app/
│   │   │   ├── globals.css      # Design system, grid bg, ambient glow
│   │   │   ├── layout.tsx
│   │   │   ├── page.tsx         # Main SPA — upload, states, results
│   │   │   └── page.module.css  # Scoped styles
│   │   └── lib/
│   │       └── api.ts           # Typed fetch wrapper
│   ├── next.config.js
│   ├── tsconfig.json
│   ├── Dockerfile               # Multi-stage standalone Next.js
│   └── .env.example
│
├── .github/
│   └── workflows/
│       └── ci.yml               # Lint + type-check + Docker build
│
├── docker-compose.yml           # Full-stack local orchestration
├── .env.example                 # Root-level shared secrets template
├── .gitignore
└── README.md
```

---

## Reference Test Data

`sales_q1_2026.csv` (included in repo root for testing):

```
Date,Product_Category,Region,Units_Sold,Unit_Price,Revenue,Status
2026-01-05,Electronics,North,150,1200,180000,Shipped
2026-01-12,Home Appliances,South,45,450,20250,Shipped
2026-01-20,Electronics,East,80,1100,88000,Delivered
2026-02-15,Electronics,North,210,1250,262500,Delivered
2026-02-28,Home Appliances,North,60,400,24000,Cancelled
2026-03-10,Electronics,West,95,1150,109250,Shipped
```

---

*Built with ☕ by the Rabbitt AI Engineering Team.*
