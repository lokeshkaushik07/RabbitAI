"use client";

import { useState, useCallback, useRef, DragEvent, ChangeEvent } from "react";
import { uploadSalesFile, UploadResponse } from "@/lib/api";
import styles from "./page.module.css";

type State = "idle" | "dragging" | "loading" | "success" | "error";

export default function Home() {
  const [state, setState] = useState<State>("idle");
  const [file, setFile] = useState<File | null>(null);
  const [email, setEmail] = useState("");
  const [result, setResult] = useState<UploadResponse | null>(null);
  const [errorMsg, setErrorMsg] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const acceptedTypes = [".csv", ".xlsx", ".xls"];

  const validateFile = (f: File): string | null => {
    const ext = "." + f.name.split(".").pop()?.toLowerCase();
    if (!acceptedTypes.includes(ext)) return `Invalid file type. Use: ${acceptedTypes.join(", ")}`;
    if (f.size > 10 * 1024 * 1024) return "File too large. Maximum size is 10 MB.";
    return null;
  };

  const handleFileSelect = useCallback((f: File) => {
    const err = validateFile(f);
    if (err) { setErrorMsg(err); setState("error"); return; }
    setFile(f);
    setState("idle");
    setErrorMsg("");
  }, []);

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setState("idle");
    const dropped = e.dataTransfer.files[0];
    if (dropped) handleFileSelect(dropped);
  };

  const onDragOver = (e: DragEvent) => { e.preventDefault(); setState("dragging"); };
  const onDragLeave = () => setState("idle");

  const onFileInput = (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) handleFileSelect(f);
  };

  const handleSubmit = async () => {
    if (!file || !email) return;
    setState("loading");
    setErrorMsg("");
    try {
      const res = await uploadSalesFile(file, email);
      setResult(res);
      setState("success");
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : "An unexpected error occurred.");
      setState("error");
    }
  };

  const reset = () => {
    setState("idle"); setFile(null); setEmail(""); setResult(null); setErrorMsg("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const isLoading = state === "loading";
  const canSubmit = !!file && email.includes("@") && !isLoading;

  return (
    <main className={styles.main}>
      {/* Header */}
      <header className={styles.header}>
        <div className={styles.logo}>
          <span className={styles.logoIcon}>🐇</span>
          <span className={styles.logoText}>RABBITT<span className={styles.logoAccent}>AI</span></span>
        </div>
        <div className={styles.badge}>
          <span className={styles.badgeDot} />
          <span>SALES INSIGHT AUTOMATOR</span>
        </div>
      </header>

      {/* Hero */}
      <section className={styles.hero}>
        <p className={styles.heroEyebrow}>// Q1 · Q2 · Q3 · Q4</p>
        <h1 className={styles.heroTitle}>
          Turn Raw Data<br />
          <span className={styles.heroAccent}>Into Intelligence</span>
        </h1>
        <p className={styles.heroSub}>
          Upload your sales CSV or Excel file. Our AI engine parses the data,<br />
          writes an executive brief, and delivers it straight to your inbox.
        </p>
      </section>

      {/* Card */}
      <div className={styles.card}>

        {state === "success" && result ? (
          /* ── Success State ──────────────────────────────── */
          <div className={styles.successPane}>
            <div className={styles.successIcon}>✦</div>
            <h2 className={styles.successTitle}>Brief Dispatched</h2>
            <p className={styles.successSub}>
              Your executive summary is on its way to<br />
              <strong>{result.recipient}</strong>
            </p>

            <div className={styles.statsRow}>
              <div className={styles.stat}>
                <span className={styles.statVal}>{result.rows_processed.toLocaleString()}</span>
                <span className={styles.statLabel}>Rows Processed</span>
              </div>
              <div className={styles.statDivider} />
              <div className={styles.stat}>
                <span className={styles.statVal}>{result.filename.split(".").pop()?.toUpperCase()}</span>
                <span className={styles.statLabel}>Format</span>
              </div>
              <div className={styles.statDivider} />
              <div className={styles.stat}>
                <span className={styles.statVal}>AI</span>
                <span className={styles.statLabel}>Generated</span>
              </div>
            </div>

            <div className={styles.preview}>
              <p className={styles.previewLabel}>// SUMMARY PREVIEW</p>
              <p className={styles.previewText}>{result.summary_preview}</p>
            </div>

            <button className={styles.resetBtn} onClick={reset}>
              ↩ Analyse Another File
            </button>
          </div>
        ) : (
          /* ── Upload Form ────────────────────────────────── */
          <>
            {/* Drop Zone */}
            <div
              className={`${styles.dropZone} ${state === "dragging" ? styles.dragging : ""} ${file ? styles.hasFile : ""}`}
              onDrop={onDrop}
              onDragOver={onDragOver}
              onDragLeave={onDragLeave}
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={onFileInput}
                className={styles.hiddenInput}
              />

              {file ? (
                <div className={styles.fileInfo}>
                  <span className={styles.fileIcon}>
                    {file.name.endsWith(".csv") ? "📄" : "📊"}
                  </span>
                  <div>
                    <p className={styles.fileName}>{file.name}</p>
                    <p className={styles.fileSize}>{(file.size / 1024).toFixed(1)} KB</p>
                  </div>
                  <button
                    className={styles.removeFile}
                    onClick={(e) => { e.stopPropagation(); setFile(null); setState("idle"); }}
                  >
                    ✕
                  </button>
                </div>
              ) : (
                <>
                  <div className={styles.dropIcon}>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                      <polyline points="17 8 12 3 7 8" />
                      <line x1="12" y1="3" x2="12" y2="15" />
                    </svg>
                  </div>
                  <p className={styles.dropText}>
                    {state === "dragging" ? "Release to upload" : "Drag & drop your sales file"}
                  </p>
                  <p className={styles.dropHint}>or click to browse — CSV, XLSX up to 10 MB</p>
                </>
              )}
            </div>

            {/* Email Field */}
            <div className={styles.field}>
              <label className={styles.label} htmlFor="email">
                <span className={styles.labelTag}>// RECIPIENT</span>
                Deliver brief to
              </label>
              <div className={styles.inputWrap}>
                <span className={styles.inputIcon}>@</span>
                <input
                  id="email"
                  type="email"
                  className={styles.input}
                  placeholder="executive@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isLoading}
                  autoComplete="email"
                />
              </div>
            </div>

            {/* Error Banner */}
            {state === "error" && errorMsg && (
              <div className={styles.errorBanner}>
                <span>⚠</span>
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Submit */}
            <button
              className={`${styles.submitBtn} ${isLoading ? styles.loading : ""}`}
              onClick={handleSubmit}
              disabled={!canSubmit}
            >
              {isLoading ? (
                <>
                  <span className={styles.spinner} />
                  <span>Generating brief…</span>
                </>
              ) : (
                <>
                  <span>Generate & Send Brief</span>
                  <span className={styles.btnArrow}>→</span>
                </>
              )}
            </button>
          </>
        )}
      </div>

      {/* Flow Steps */}
      <div className={styles.steps}>
        {[
          { n: "01", label: "Upload", desc: "CSV or XLSX file" },
          { n: "02", label: "Analyse", desc: "AI reads & synthesises" },
          { n: "03", label: "Deliver", desc: "Brief hits your inbox" },
        ].map((s) => (
          <div key={s.n} className={styles.step}>
            <span className={styles.stepNum}>{s.n}</span>
            <span className={styles.stepLabel}>{s.label}</span>
            <span className={styles.stepDesc}>{s.desc}</span>
          </div>
        ))}
      </div>

      {/* Footer */}
      <footer className={styles.footer}>
        <span>Rabbitt AI © 2026</span>
        <span className={styles.footerDot}>·</span>
        <a href="/api/docs" target="_blank" rel="noopener" className={styles.footerLink}>API Docs</a>
        <span className={styles.footerDot}>·</span>
        <span>Secured · Rate-limited · CORS-protected</span>
      </footer>
    </main>
  );
}
