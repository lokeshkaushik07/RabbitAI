export interface UploadResponse {
  success: boolean;
  message: string;
  recipient: string;
  filename: string;
  rows_processed: number;
  summary_preview: string;
}

export interface ApiError {
  detail: string;
}

export async function uploadSalesFile(
  file: File,
  recipientEmail: string
): Promise<UploadResponse> {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  const apiKey = process.env.NEXT_PUBLIC_API_KEY || "";

  const formData = new FormData();
  formData.append("file", file);
  formData.append("recipient_email", recipientEmail);

  const response = await fetch(`${apiUrl}/api/v1/upload`, {
    method: "POST",
    headers: { "X-API-Key": apiKey },
    body: formData,
  });

  const data = await response.json();

  if (!response.ok) {
    const msg = (data as ApiError).detail || `HTTP ${response.status}`;
    throw new Error(msg);
  }

  return data as UploadResponse;
}
