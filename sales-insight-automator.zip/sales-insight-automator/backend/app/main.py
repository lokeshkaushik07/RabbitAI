from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from slowapi.util import get_remote_address
import time

from app.core.config import get_settings
from app.routers import upload, health

settings = get_settings()

# ── Rate Limiter ──────────────────────────────────────────────────────────────
limiter = Limiter(key_func=get_remote_address, default_limits=[settings.RATE_LIMIT_DEFAULT])

# ── FastAPI App ───────────────────────────────────────────────────────────────
app = FastAPI(
    title="Sales Insight Automator API",
    description="""
## 🐇 Rabbitt AI — Sales Insight Automator

Upload a `.csv` or `.xlsx` sales data file and receive an AI-generated executive brief
delivered directly to a specified inbox.

### Authentication
All `/api/v1/*` endpoints require an `X-API-Key` header.

### Rate Limits
- Default: **60 requests / minute** per IP
- Upload endpoint: **10 requests / minute** per IP

### Workflow
1. `POST /api/v1/upload` — upload file + recipient email
2. AI parses and generates an executive summary
3. Summary is emailed via SendGrid
4. JSON response includes a preview of the brief
    """,
    version=settings.APP_VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    contact={
        "name": "Rabbitt AI Engineering",
        "email": "engineering@rabbittai.com",
    },
    license_info={"name": "Proprietary"},
)

# ── Middleware Stack ───────────────────────────────────────────────────────────

# 1. Rate limiting
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)

# 2. CORS — restrict origins in production
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "X-API-Key"],
)

# 3. Security headers middleware
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
    response.headers["X-Process-Time"] = str(round(time.time() - start, 4))
    # Remove server identification
    response.headers.pop("server", None)
    return response


# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(health.router)
app.include_router(upload.router)


# ── Root redirect ─────────────────────────────────────────────────────────────
@app.get("/", include_in_schema=False)
async def root():
    return JSONResponse(
        {"service": "Sales Insight Automator API", "docs": "/docs", "health": "/health"}
    )
