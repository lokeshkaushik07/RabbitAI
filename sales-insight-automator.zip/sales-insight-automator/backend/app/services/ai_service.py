import json
import httpx

from app.core.config import get_settings

settings = get_settings()

SYSTEM_PROMPT = """You are a senior business analyst at Rabbitt AI. 
Your task is to produce a concise, professional executive summary of sales data provided as a JSON statistical report.

Guidelines:
- Write in clear, confident business prose (3–5 paragraphs).
- Lead with the most impactful headline metric.
- Highlight trends, top performers, anomalies, and risks.
- Close with 2–3 actionable recommendations.
- Do NOT repeat raw numbers verbatim from every field — synthesise and interpret.
- Use USD formatting for monetary values. 
- Tone: executive briefing, not a data dump.
"""


class AIServiceError(Exception):
    pass


async def generate_summary(data_summary: dict) -> str:
    """Route to the configured AI provider and return the narrative summary."""
    payload = json.dumps(data_summary, indent=2, default=str)
    user_message = (
        f"Here is the statistical summary of this quarter's sales data:\n\n"
        f"```json\n{payload}\n```\n\n"
        f"Please write the executive sales brief now."
    )

    provider = settings.AI_PROVIDER.lower()
    if provider == "gemini":
        return await _call_gemini(user_message)
    elif provider == "groq":
        return await _call_groq(user_message)
    else:
        raise AIServiceError(f"Unknown AI_PROVIDER: '{provider}'. Use 'gemini' or 'groq'.")


# ── Gemini ────────────────────────────────────────────────────────────────────

async def _call_gemini(user_message: str) -> str:
    if not settings.GEMINI_API_KEY:
        raise AIServiceError("GEMINI_API_KEY is not configured.")

    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"gemini-1.5-flash:generateContent?key={settings.GEMINI_API_KEY}"
    )
    body = {
        "system_instruction": {"parts": [{"text": SYSTEM_PROMPT}]},
        "contents": [{"role": "user", "parts": [{"text": user_message}]}],
        "generationConfig": {"temperature": 0.4, "maxOutputTokens": 1024},
    }

    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(url, json=body)

    if resp.status_code != 200:
        raise AIServiceError(f"Gemini API error {resp.status_code}: {resp.text[:200]}")

    data = resp.json()
    try:
        return data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except (KeyError, IndexError) as exc:
        raise AIServiceError(f"Unexpected Gemini response shape: {exc}") from exc


# ── Groq ──────────────────────────────────────────────────────────────────────

async def _call_groq(user_message: str) -> str:
    if not settings.GROQ_API_KEY:
        raise AIServiceError("GROQ_API_KEY is not configured.")

    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {settings.GROQ_API_KEY}",
        "Content-Type": "application/json",
    }
    body = {
        "model": "llama3-70b-8192",
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_message},
        ],
        "temperature": 0.4,
        "max_tokens": 1024,
    }

    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(url, json=body, headers=headers)

    if resp.status_code != 200:
        raise AIServiceError(f"Groq API error {resp.status_code}: {resp.text[:200]}")

    data = resp.json()
    try:
        return data["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError) as exc:
        raise AIServiceError(f"Unexpected Groq response shape: {exc}") from exc
