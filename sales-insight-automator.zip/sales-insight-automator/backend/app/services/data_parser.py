import io
import os
from pathlib import Path

import pandas as pd

from app.core.config import get_settings
from app.core.security import ALLOWED_EXTENSIONS

settings = get_settings()

MAX_BYTES = settings.MAX_FILE_SIZE_MB * 1024 * 1024


class DataParseError(Exception):
    pass


def parse_uploaded_file(filename: str, contents: bytes) -> dict:
    """
    Safely parse a CSV or XLSX file into a structured summary dict.
    Raises DataParseError on invalid input.
    """
    # Validate size
    if len(contents) > MAX_BYTES:
        raise DataParseError(
            f"File exceeds maximum size of {settings.MAX_FILE_SIZE_MB} MB."
        )

    # Validate extension
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise DataParseError(
            f"Unsupported file type '{ext}'. Allowed: {', '.join(ALLOWED_EXTENSIONS)}"
        )

    # Validate filename length
    if len(filename) > 255:
        raise DataParseError("Filename is too long.")

    try:
        buffer = io.BytesIO(contents)
        if ext == ".csv":
            df = pd.read_csv(buffer)
        else:
            df = pd.read_excel(buffer, engine="openpyxl")
    except Exception as exc:
        raise DataParseError(f"Could not parse file: {exc}") from exc

    if df.empty:
        raise DataParseError("The uploaded file contains no data.")

    if len(df) > 50_000:
        raise DataParseError("File contains too many rows (max 50,000).")

    # Sanitize column names – strip whitespace
    df.columns = df.columns.str.strip()

    return _build_summary(df)


def _build_summary(df: pd.DataFrame) -> dict:
    """Extract key statistics from the dataframe."""
    summary: dict = {
        "row_count": int(len(df)),
        "column_count": int(len(df.columns)),
        "columns": df.columns.tolist(),
        "sample_rows": df.head(5).to_dict(orient="records"),
        "numeric_stats": {},
        "categorical_stats": {},
    }

    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            summary["numeric_stats"][col] = {
                "min": _safe_val(df[col].min()),
                "max": _safe_val(df[col].max()),
                "mean": round(float(df[col].mean()), 2),
                "sum": _safe_val(df[col].sum()),
                "null_count": int(df[col].isnull().sum()),
            }
        else:
            top = df[col].value_counts().head(5).to_dict()
            summary["categorical_stats"][col] = {
                "unique_values": int(df[col].nunique()),
                "top_values": {str(k): int(v) for k, v in top.items()},
                "null_count": int(df[col].isnull().sum()),
            }

    return summary


def _safe_val(val):
    """Convert numpy types to native Python for JSON serialisation."""
    try:
        return round(float(val), 2)
    except (TypeError, ValueError):
        return str(val)
