import os
import re
from pathlib import Path

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Request,
    UploadFile,
    status,
)
from pydantic import EmailStr, ValidationError

from app.core.config import get_settings
from app.core.security import verify_api_key, ALLOWED_EXTENSIONS
from app.models.schemas import UploadResponse
from app.services.ai_service import generate_summary, AIServiceError
from app.services.data_parser import parse_uploaded_file, DataParseError
from app.services.email_service import send_summary_email, EmailServiceError

router = APIRouter(prefix="/api/v1", tags=["Sales Insights"])
settings = get_settings()

EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$")


@router.post(
    "/upload",
    response_model=UploadResponse,
    summary="Upload sales file and generate AI summary",
    description=(
        "Accepts a `.csv` or `.xlsx` sales data file plus a recipient email address. "
        "The backend parses the file, generates an executive brief via an LLM, and "
        "delivers it to the specified inbox. **Requires `X-API-Key` header.**"
    ),
    responses={
        200: {"description": "Summary generated and email dispatched."},
        400: {"description": "Invalid file or email input."},
        403: {"description": "Missing or invalid API key."},
        413: {"description": "File too large."},
        429: {"description": "Rate limit exceeded."},
        502: {"description": "Upstream AI or email service error."},
    },
)
async def upload_and_analyse(
    request: Request,
    file: UploadFile = File(..., description="CSV or XLSX file (max 10 MB)"),
    recipient_email: str = Form(..., description="Destination email for the summary"),
    _: str = Depends(verify_api_key),
):
    # ── Input validation ──────────────────────────────────────────────────────
    # Email validation
    recipient_email = recipient_email.strip().lower()
    if not EMAIL_REGEX.match(recipient_email):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid email address format.",
        )

    # Filename sanitisation
    filename = os.path.basename(file.filename or "upload")
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported file type. Allowed: {', '.join(ALLOWED_EXTENSIONS)}",
        )

    # Size guard (stream first 10 MB + 1 byte to detect oversized)
    max_bytes = settings.MAX_FILE_SIZE_MB * 1024 * 1024
    contents = await file.read(max_bytes + 1)
    if len(contents) > max_bytes:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File exceeds maximum size of {settings.MAX_FILE_SIZE_MB} MB.",
        )

    # ── Parse data ────────────────────────────────────────────────────────────
    try:
        data_summary = parse_uploaded_file(filename, contents)
    except DataParseError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))

    # ── Generate AI summary ───────────────────────────────────────────────────
    try:
        ai_summary = await generate_summary(data_summary)
    except AIServiceError as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"AI service error: {exc}",
        )

    # ── Send email ────────────────────────────────────────────────────────────
    try:
        await send_summary_email(recipient_email, ai_summary, filename)
    except EmailServiceError as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Email service error: {exc}",
        )

    return UploadResponse(
        success=True,
        message="Sales brief generated and dispatched successfully.",
        recipient=recipient_email,
        filename=filename,
        rows_processed=data_summary["row_count"],
        summary_preview=ai_summary[:300] + ("…" if len(ai_summary) > 300 else ""),
    )
