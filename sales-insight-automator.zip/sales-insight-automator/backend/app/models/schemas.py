from pydantic import BaseModel, EmailStr, Field
from typing import Any


class UploadResponse(BaseModel):
    success: bool
    message: str
    recipient: EmailStr
    filename: str
    rows_processed: int
    summary_preview: str = Field(
        description="First 300 characters of the generated summary"
    )


class HealthResponse(BaseModel):
    status: str
    version: str
    environment: str


class ErrorResponse(BaseModel):
    detail: str
    error_code: str | None = None
